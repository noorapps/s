config.brandingDataUrl = 'https://rawcdn.githack.com/maxired/myjitsi/master/branding.json'
